# CLI Reference (v3.0.x)

Complete reference for `graphql-codegen` CLI commands in v3.0.x.

**⚠️ Breaking Changes in v3.0.x:**
- Unified command: Use `--react-query` and `--orm` flags instead of separate `generate` and `generate-orm` commands
- `--schema` renamed to `--schema-file`
- New flags: `--schemas`, `--api-names` for database introspection
- Watch mode removed (use external file watchers)

## graphql-codegen

Generate type-safe React Query hooks and/or ORM client from GraphQL schema.

```bash
npx graphql-codegen [options]
```

### Source Options (choose one)

| Option | Alias | Description | Default |
|--------|-------|-------------|---------|
| `--endpoint <url>` | `-e` | GraphQL endpoint URL | - |
| `--schema-file <path>` | `-s` | Path to GraphQL schema file (.graphql) | - |
| `--schemas <list>` | - | PostgreSQL schemas (comma-separated) | - |
| `--api-names <list>` | - | API names for auto schema discovery | - |
| `--config <path>` | `-c` | Path to config file | `graphql-codegen.config.ts` |

### Generator Options

| Option | Description | Default |
|--------|-------------|---------|
| `--react-query` | Generate React Query hooks | `false` |
| `--orm` | Generate ORM client | `false` |

### Output Options

| Option | Alias | Description | Default |
|--------|-------|-------------|---------|
| `--output <dir>` | `-o` | Output directory | `./generated/graphql` |
| `--target <name>` | `-t` | Target name (for multi-target configs) | - |

### Other Options

| Option | Alias | Description | Default |
|--------|-------|-------------|---------|
| `--authorization <token>` | `-a` | Authorization header value | - |
| `--verbose` | `-v` | Show detailed output | `false` |
| `--dry-run` | - | Preview without writing files | `false` |
| `--keep-db` | - | Keep ephemeral database (debugging) | `false` |
| `--help` | `-h` | Show help message | - |
| `--version` | - | Show version number | - |

## Examples

### From GraphQL Endpoint

```bash
# Generate React Query hooks
npx graphql-codegen --react-query -e https://api.example.com/graphql

# Generate ORM client
npx graphql-codegen --orm -e https://api.example.com/graphql

# Generate both
npx graphql-codegen --react-query --orm -e https://api.example.com/graphql

# With custom output
npx graphql-codegen --react-query -e https://api.example.com/graphql -o ./src/generated

# With authorization
npx graphql-codegen --orm -e https://api.example.com/graphql -a "Bearer token123"
```

### From Schema File

```bash
# Generate from .graphql file
npx graphql-codegen --react-query -s ./schema.graphql -o ./generated

# With both generators
npx graphql-codegen --react-query --orm -s ./schema.graphql
```

### From Database (v3.0)

```bash
# Explicit schemas
npx graphql-codegen --react-query --schemas public,app_public

# Auto-discover from API names
npx graphql-codegen --orm --api-names my_api

# With custom output
npx graphql-codegen --react-query --schemas public -o ./generated
```

### Using Config File

```bash
# Use default config file (graphql-codegen.config.ts)
npx graphql-codegen

# Use specific config file
npx graphql-codegen -c ./config/codegen.config.ts

# Override config with CLI options
npx graphql-codegen -c ./config.ts --react-query --orm

# Multi-target: generate specific target
npx graphql-codegen -t production

# Multi-target: generate all targets
npx graphql-codegen
```

### Development Workflow

```bash
# Dry run to preview changes
npx graphql-codegen --react-query -e https://api.example.com/graphql --dry-run

# Verbose output for debugging
npx graphql-codegen --orm -e https://api.example.com/graphql -v

# Keep ephemeral database for debugging (when using PGPM modules)
npx graphql-codegen --schemas public --keep-db
```

## Migration from v2.x

### Command Changes

```bash
# v2.x (OLD)
npx graphql-codegen generate -e URL
npx graphql-codegen generate-orm -e URL
npx graphql-codegen generate --watch

# v3.x (NEW)
npx graphql-codegen --react-query -e URL
npx graphql-codegen --orm -e URL
# Watch mode removed - use external file watchers
```

### Flag Changes

```bash
# v2.x (OLD)
npx graphql-codegen generate -s ./schema.graphql

# v3.x (NEW)
npx graphql-codegen --react-query -s ./schema.graphql
# OR
npx graphql-codegen --react-query --schema-file ./schema.graphql
```

## Environment Variables

The CLI respects these environment variables:

| Variable | Description |
|----------|-------------|
| `PGHOST` | PostgreSQL host (for database introspection) |
| `PGPORT` | PostgreSQL port |
| `PGDATABASE` | PostgreSQL database name |
| `PGUSER` | PostgreSQL user |
| `PGPASSWORD` | PostgreSQL password |

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | General error |
| `2` | Configuration error |
| `3` | Network/schema error |

## Removed Features (v3.0)

### Watch Mode

Watch mode has been removed in v3.0. Use external file watchers instead:

```bash
# Using nodemon
nodemon --watch schema.graphql --exec "npx graphql-codegen --react-query -s schema.graphql"

# Using chokidar-cli
chokidar "schema.graphql" -c "npx graphql-codegen --react-query -s schema.graphql"

# Using watchexec
watchexec -w schema.graphql -- npx graphql-codegen --react-query -s schema.graphql
```

### Separate Commands

The `generate` and `generate-orm` commands have been unified. Use `--react-query` and `--orm` flags instead.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Unknown command: generate" | Use `--react-query` flag instead of `generate` command |
| "Unknown option: --schema" | Use `--schema-file` instead (renamed in v3.0) |
| No code generated | Add `--react-query` or `--orm` flag |
| "Cannot use both endpoint and schemas" | Choose one schema source |
| "schemas and apiNames are mutually exclusive" | Use either `--schemas` or `--api-names`, not both |
| Database connection errors | Check `PG*` environment variables |
