---
name: constructive-data-modeling
description: "Tables, fields, relations, constraints, indexes, enums, views, and database provisioning via the type-safe SDK. Use when asked to 'create a table', 'add a field', 'add a column', 'create a relation', 'add a constraint', 'add an index', 'create a foreign key', 'add a primary key', 'add a unique constraint', 'define field types', 'provision a database', 'create an enum', 'create a view', 'security_invoker', 'security_barrier', 'WITH CHECK OPTION', 'check_option', 'api_required', 'temporal table', 'application-time temporal', 'WITHOUT OVERLAPS', 'temporal foreign key', 'WITH PERIOD', 'period column', or when working with metaschema_public operations."
metadata:
  author: constructive-io
  version: "1.0.0"
---

# Constructive Data Modeling

Tables, fields, relations, constraints, and indexes — the full schema lifecycle via the type-safe SDK. Everything compiles to PostgreSQL DDL through Constructive's metaschema layer.

## When to Apply

Use this skill when:
- Creating tables, fields, relations, constraints, or indexes via the SDK
- Provisioning databases with module selection
- Defining enum types
- Creating views and setting view options (`security_invoker`, `security_barrier`, `WITH [LOCAL|CASCADED] CHECK OPTION`)
- Configuring field validation (regexp, min, max)
- Setting `api_required` on nullable FK columns
- Adding primary key / unique / foreign key constraints
- Declaring application-time temporal constraints (PG18): `WITHOUT OVERLAPS` keys and temporal (`WITH PERIOD`) foreign keys
- Understanding the composition: table → fields → constraints → indexes → relations → security

## The Composition Flow

```
1. Provision database  → db.databaseProvisionModule.create({ modules: ['all'] })
2. Create table        → db.secureTableProvision.create({ tableName, nodeType, ... })
3. Add fields          → db.field.create({ tableId, name, type, ... })
4. Add constraints     → db.checkConstraint.create / db.foreignKeyConstraint.create
5. Add indexes         → db.index.create({ tableId, fieldIds, ... })
6. Add relations       → db.relationProvision.create({ fromTableId, toTableId, ... })
7. Apply security      → see constructive-security skill
```

## Database Provisioning

```typescript
const result = await db.databaseProvisionModule.create({
  data: {
    databaseName: 'my-app',
    ownerId: userId,
    subdomain: 'my-app',
    domain: 'localhost',
    modules: ['all'],
    bootstrapUser: true,
  },
  select: { id: true, databaseId: true, status: true },
}).execute();
```

See [provisioning.md](./references/provisioning.md) for the full provisioning flow.

## Tables

Create tables via `secureTableProvision` (recommended) or `db.table.create`:

```typescript
await db.secureTableProvision.create({
  data: {
    databaseId,
    tableName: 'projects',
    nodeType: 'DataEntityMembership',
    useRls: true,
    grantRoles: ['authenticated'],
    grantPrivileges: [['select', '*'], ['insert', '*'], ['update', '*'], ['delete', '*']] as unknown as Record<string, unknown>,
    policyType: 'AuthzEntityMembership',
    policyPermissive: true,
    policyData: { entity_field: 'entity_id', membership_type: 2 },
  },
  select: { id: true, tableId: true, outFields: true },
}).execute();
```

For full table management operations, see the generated `orm-*` skills in `constructive-db`.

## Fields

```typescript
await db.field.create({
  data: {
    databaseId,
    tableId,
    name: 'status',
    type: { name: 'project_status' },  // enum type
    defaultValue: { value: 'draft' },
    isRequired: true,
  },
  select: { id: true },
}).execute();
```

Field types include: `text`, `integer`, `bigint`, `boolean`, `uuid`, `jsonb`, `timestamptz`, `date`, `numeric`, `citext`, `ltree`, `vector(N)`, and custom enums.

See [field-types.md](./references/field-types.md) for the complete type reference.

## Enum Types

```typescript
await db.enum.create({
  data: {
    databaseId,
    schemaName: 'app_public',
    name: 'project_status',
    values: ['draft', 'active', 'archived'],
  },
  select: { id: true, name: true, values: true },
}).execute();
```

## Relations

Four relation types via `db.relationProvision.create`:

| Type | Description |
|------|-------------|
| `BelongsTo` | FK on source → target PK (default) |
| `HasMany` | FK on target → source PK |
| `HasOne` | FK on target → source PK (unique) |
| `ManyToMany` | Junction table auto-created |

```typescript
await db.relationProvision.create({
  data: {
    databaseId,
    fromTableId: projectsTableId,
    toTableId: organizationsTableId,
    fromFieldName: 'organization_id',
    apiRequired: true,
    cascadeDelete: 'no_action',
  },
  select: { id: true },
}).execute();
```

## Constraints

Primary keys, unique constraints, foreign keys, and check constraints via
`db.primaryKeyConstraint.create`, `db.uniqueConstraint.create`,
`db.foreignKeyConstraint.create`, and `db.checkConstraint.create`. `fieldIds` is
an ordered array; composite keys follow the array order.

```typescript
await db.foreignKeyConstraint.create({
  data: {
    databaseId,
    tableId,                       // referencing (child) table
    fieldIds: [authorIdFieldId],   // local columns
    refTableId: usersTableId,      // referenced (parent) table
    refFieldIds: [userIdFieldId],  // referenced columns
    deleteAction: 'a',             // a=NO ACTION, r=RESTRICT, c=CASCADE, n=SET NULL, d=SET DEFAULT
    updateAction: 'a',
  },
  select: { id: true },
}).execute();
```

### Application-time temporal constraints (PostgreSQL 18)

Pair an ordinary scalar key with a **period column** (a range type such as
`tstzrange`, added as a normal field) to get temporal keys. Three optional flags
expose this — all default to `false`, so existing constraints are unchanged. The
period column must be the **last** entry in `fieldIds` (and `refFieldIds`).

```typescript
// PRIMARY KEY (room_id, valid_period WITHOUT OVERLAPS)
await db.primaryKeyConstraint.create({
  data: { databaseId, tableId, fieldIds: [roomIdFieldId, periodFieldId], withoutOverlaps: true },
  select: { id: true },
}).execute();

// UNIQUE (room_id, valid_period WITHOUT OVERLAPS)  → db.uniqueConstraint.create + withoutOverlaps: true

// FOREIGN KEY (room_id, PERIOD valid_period) REFERENCES room (id, PERIOD valid_period)
await db.foreignKeyConstraint.create({
  data: {
    databaseId, tableId: bookingTableId,
    fieldIds: [bookingRoomIdFieldId, bookingPeriodFieldId],
    refTableId: roomTableId, refFieldIds: [roomIdFieldId, roomPeriodFieldId],
    withPeriod: true,
  },
  select: { id: true },
}).execute();
```

Temporal PK/UNIQUE build a GiST-backed exclusion index and require the
`btree_gist` extension. A temporal FK must reference a temporal key on the
parent. See [constraints.md](./references/constraints.md) for full examples and
rules.

## Indexes

```typescript
await db.index.create({
  data: {
    databaseId,
    tableId,
    fieldIds: [fieldId],
    isUnique: true,
    accessMethod: 'btree',  // or 'gin', 'gist', 'hash'
  },
  select: { id: true },
}).execute();
```

## Views

Create views via `db.view.create`; `viewType` selects the view body (`View*` node
type). Three optional options control PostgreSQL storage attributes and update
semantics: `securityInvoker` (default `true`), `securityBarrier` (default
`false`), and `checkOption` (`null | 'local' | 'cascaded'`).

```typescript
await db.view.create({
  data: {
    databaseId,
    schemaId,
    name: 'owners_view',
    viewType: 'ViewTableProjection',
    tableId: ownersTableId,
    data: { source_schema: 'app_public', source_table: 'owners' },
    securityBarrier: true,
    checkOption: 'cascaded',
    isReadOnly: false,
  },
  select: { id: true },
}).execute();
// → CREATE VIEW app_public.owners_view
//     WITH (security_invoker = true, security_barrier = true) AS
//     SELECT ... WITH CASCADED CHECK OPTION
```

See [views.md](./references/views.md) for all view options and generated SQL.

## `api_required` (Required API Fields)

For nullable FK columns that should be required at the GraphQL API level:

```typescript
await db.field.update({
  where: { id: fieldId },
  data: { apiRequired: true },
  select: { id: true },
}).execute();
```

## References

| File | Content |
|------|---------|
| [constraints.md](./references/constraints.md) | Primary key, unique, foreign key, check + application-time temporal (`WITHOUT OVERLAPS` / `WITH PERIOD`) constraints |
| [field-types.md](./references/field-types.md) | Complete field type reference |
| [provisioning.md](./references/provisioning.md) | Full database provisioning flow |
| [views.md](./references/views.md) | View creation + options (`securityInvoker`, `securityBarrier`, `WITH [LOCAL\|CASCADED] CHECK OPTION`) |

## Cross-References

- **Security (RLS, grants, policies):** [`constructive-security`](../constructive-security/SKILL.md)
- **Blueprint definitions:** [`constructive-blueprints`](../constructive-blueprints/SKILL.md)
- **Generated ORM API:** [`constructive-orm`](../constructive-orm/SKILL.md)
- **Code generation pipeline:** [`constructive-codegen`](../constructive-codegen/SKILL.md)
